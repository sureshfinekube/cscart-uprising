<?php


namespace Tygh\Tools\Archivers;

use Tygh\Exceptions\AException;

/**
 * Class ArchiverException
 * @package Tygh\Tools
 */
class ArchiverException extends AException
{

}